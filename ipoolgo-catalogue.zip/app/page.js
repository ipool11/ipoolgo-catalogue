
export default function HomePage() {
  const services = [
    {
      title: "Premium Services",
      description:
        "We deliver high-quality solutions to clients worldwide with fast turnaround times and reliable support.",
    },
    {
      title: "Secure Payments",
      description:
        "Accept payments from anywhere in the world using trusted payment gateways.",
    },
    {
      title: "24/7 Support",
      description:
        "We're available to answer your questions and support your business needs.",
    },
  ];

  return (
    <div className="min-h-screen bg-white text-gray-900">
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">iPoolGo Catalogue</h1>
          <nav className="hidden md:flex gap-6 text-sm font-medium">
            <a href="#services">Services</a>
            <a href="#contact">Contact</a>
          </nav>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 py-24 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <p className="text-blue-600 font-semibold mb-4">Serving Clients Worldwide</p>
          <h2 className="text-5xl font-bold leading-tight mb-6">
            Premium Swimming Pools & Outdoor Solutions
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            We supply high-quality inflatable and custom pools for homes, hotels,
            and commercial projects worldwide.
          </p>
          <a
            href="#contact"
            className="px-6 py-3 bg-blue-600 text-white rounded-2xl shadow hover:bg-blue-700"
          >
            Request a Quote
          </a>
        </div>

        <div className="bg-gray-100 rounded-3xl p-10 shadow-lg">
          <h3 className="text-2xl font-semibold mb-4">Why Choose iPoolGo?</h3>
          <ul className="space-y-3 text-gray-700">
            <li>✔ Global Shipping</li>
            <li>✔ Premium Quality</li>
            <li>✔ Secure Payments</li>
            <li>✔ Dedicated Support</li>
          </ul>
        </div>
      </section>

      <section id="services" className="bg-gray-50 py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-4xl font-bold text-center mb-12">Our Services</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 rounded-3xl shadow-sm border">
                <h4 className="text-xl font-semibold mb-4">{service.title}</h4>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h3 className="text-4xl font-bold mb-6">Contact Us</h3>
          <p className="text-gray-600 mb-8">
            Ready to order? Reach out today.
          </p>
          <div className="space-y-2 text-lg">
            <p>Email: your@email.com</p>
            <p>WhatsApp: +234 XXX XXX XXXX</p>
            <p>Telegram: @yourusername</p>
          </div>
        </div>
      </section>

      <footer className="border-t border-gray-200 py-8 text-center text-gray-500 text-sm">
        © {new Date().getFullYear()} iPoolGo Catalogue. All rights reserved.
      </footer>
    </div>
  );
}
